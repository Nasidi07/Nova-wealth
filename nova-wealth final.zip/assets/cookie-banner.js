/**
 * Nova Wealth — Cookie Consent Banner (injectable)
 *
 * Inject this script into any page. It builds and manages the full
 * cookie-consent UI using the Nova Wealth brand tokens.
 *
 * Storage key: nova_cookie_consent
 *
 * Usage:
 *   <script src="cookie-banner.js"></script>
 *
 * Preferences are stored as:
 *   { essential, analytics, marketing, personalization, timestamp }
 */
(function () {
  if (document.getElementById('novaCookieBanner')) return; // already mounted

  var STORAGE_KEY = 'nova_cookie_consent';

  // ── Brand tokens ──
  var T = {
    bg:        '#101C2E',
    card:      '#1A3354',
    accent:    '#0AB68B',
    text:      '#F0F4F8',
    muted:     '#94A3B8',
    border:    '#1E3A5F',
    font:      "'Inter', system-ui, sans-serif"
  };

  // ── Inject styles once ──
  (function injectStyles() {
    if (document.getElementById('novaCookieStyles')) return;
    var s = document.createElement('style');
    s.id = 'novaCookieStyles';
    s.textContent = [
      '@import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap");',
      '.nova-cookie-banner{position:fixed;bottom:0;left:0;right:0;z-index:9999;display:flex;justify-content:center;transform:translateY(100%);animation:cookieSlideUp .6s cubic-bezier(.22,1,.36,1) forwards;padding:0 16px 16px;pointer-events:none}.nova-cookie-banner.hidden{animation:cookieSlideDown .45s cubic-bezier(.55,.085,.68,.53) forwards;pointer-events:none}',
      '.nova-cookie-card{pointer-events:auto;width:100%;max-width:960px;background:rgba(26,51,84,.78);border:1px solid rgba(30,58,95,.6);border-radius:16px;padding:24px 28px;backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);box-shadow:0 -4px 40px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.04);display:flex;align-items:center;gap:20px;font-family:' + T.font + '}',
      '.nova-cookie-icon{flex-shrink:0;width:44px;height:44px;background:rgba(10,182,139,.12);border:1px solid rgba(10,182,139,.25);border-radius:12px;display:flex;align-items:center;justify-content:center}.nova-cookie-icon svg{width:24px;height:24px}',
      '.nova-cookie-body{flex:1}.nova-cookie-text{font-size:.9rem;color:' + T.muted + ';line-height:1.55}.nova-cookie-text a{color:' + T.accent + ';text-decoration:underline;text-underline-offset:2px;transition:color .2s}.nova-cookie-text a:hover{color:#099e7a}',
      '.nova-cookie-actions{display:flex;align-items:center;gap:10px;flex-shrink:0;flex-wrap:wrap}',
      '.nova-btn{font-family:' + T.font + ';font-size:.82rem;font-weight:600;padding:10px 18px;border-radius:10px;cursor:pointer;transition:all .22s;white-space:nowrap;border:none}',
      '.nova-btn-ghost{background:transparent;color:' + T.muted + ';border:1px solid ' + T.border + '}.nova-btn-ghost:hover{background:rgba(255,255,255,.06);color:' + T.text + ';border-color:' + T.muted + '}',
      '.nova-btn-accent{background:linear-gradient(135deg,' + T.accent + ',#099e7a);color:' + T.bg + ';box-shadow:0 2px 14px rgba(10,182,139,.28)}.nova-btn-accent:hover{background:linear-gradient(135deg,#099e7a,' + T.accent + ');box-shadow:0 4px 20px rgba(10,182,139,.38);transform:translateY(-1px)}',
      '.nova-cookie-overlay{position:fixed;inset:0;z-index:10000;background:rgba(16,28,46,.65);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:20px;opacity:0;visibility:hidden;transition:opacity .3s,visibility .3s}.nova-cookie-overlay.open{opacity:1;visibility:visible}',
      '.nova-cookie-modal{width:100%;max-width:520px;background:' + T.card + ';border:1px solid ' + T.border + ';border-radius:18px;padding:32px;box-shadow:0 20px 60px rgba(0,0,0,.45);transform:translateY(24px) scale(.97);transition:transform .35s cubic-bezier(.22,1,.36,1);font-family:' + T.font + '}.nova-cookie-overlay.open .nova-cookie-modal{transform:translateY(0) scale(1)}',
      '.nova-modal-title{font-size:1.2rem;font-weight:700;margin-bottom:4px;color:' + T.text + '}.nova-modal-sub{font-size:.85rem;color:' + T.muted + ';margin-bottom:24px}',
      '.nova-toggle-row{display:flex;align-items:center;justify-content:space-between;padding:14px 0;border-bottom:1px solid rgba(30,58,95,.5)}.nova-toggle-row:last-child{border-bottom:none}.nova-toggle-label{font-size:.9rem;font-weight:500;color:' + T.text + '}.nova-toggle-desc{font-size:.78rem;color:' + T.muted + ';margin-top:2px}.nova-toggle-label-group{display:flex;flex-direction:column;gap:2px}',
      '.nova-switch{position:relative;width:46px;height:26px;flex-shrink:0;margin-left:16px}.nova-switch input{opacity:0;width:0;height:0}.nova-switch-track{position:absolute;inset:0;background:rgba(148,163,184,.2);border-radius:13px;cursor:pointer;transition:background .25s}.nova-switch input:checked+.nova-switch-track{background:' + T.accent + '}.nova-switch-thumb{position:absolute;top:3px;left:3px;width:20px;height:20px;background:#fff;border-radius:50%;transition:transform .25s cubic-bezier(.22,1,.36,1);box-shadow:0 1px 4px rgba(0,0,0,.25)}.nova-switch input:checked~.nova-switch-thumb{transform:translateX(20px)}.nova-switch input:disabled+.nova-switch-track{opacity:.5;cursor:not-allowed}',
      '.nova-modal-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:24px}',
      '@media(max-width:640px){.nova-cookie-card{flex-direction:column;text-align:center;padding:20px}.nova-cookie-actions{justify-content:center;width:100%}.nova-btn{flex:1;min-width:0}}',
      '@keyframes cookieSlideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}',
      '@keyframes cookieSlideDown{from{transform:translateY(0);opacity:1}to{transform:translateY(100%);opacity:0}}'
    ].join('\n');
    document.head.appendChild(s);
  })();

  // ── Cookie SVG icon ──
  var COOKIE_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="' + T.accent + '" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
      '<circle cx="12" cy="12" r="10"/>' +
      '<circle cx="8.5" cy="9.5" r="1.1" fill="' + T.accent + '" stroke="none"/>' +
      '<circle cx="14" cy="8" r="1.1" fill="' + T.accent + '" stroke="none"/>' +
      '<circle cx="11" cy="14" r="1.1" fill="' + T.accent + '" stroke="none"/>' +
      '<circle cx="16" cy="13" r="1.1" fill="' + T.accent + '" stroke="none"/>' +
      '<path d="M9 17c1.5-1 3.5-1 5 0" stroke="' + T.accent + '" stroke-width="1.5"/>' +
    '</svg>';

  // ── Build HTML ──
  var bannerHTML =
    '<div class="nova-cookie-card">' +
      '<div class="nova-cookie-icon">' + COOKIE_SVG + '</div>' +
      '<div class="nova-cookie-body">' +
        '<p class="nova-cookie-text">' +
          'We use cookies to improve your experience. By continuing, you agree to our ' +
          '<a href="legal.html">Cookie Policy</a>.' +
        '</p>' +
      '</div>' +
      '<div class="nova-cookie-actions">' +
        '<button class="nova-btn nova-btn-ghost" data-nova-action="manage">Manage Preferences</button>' +
        '<button class="nova-btn nova-btn-ghost" data-nova-action="reject">Reject All</button>' +
        '<button class="nova-btn nova-btn-accent" data-nova-action="accept">Accept All</button>' +
      '</div>' +
    '</div>';

  var overlayHTML =
    '<div class="nova-cookie-modal">' +
      '<h2 class="nova-modal-title">Cookie Preferences</h2>' +
      '<p class="nova-modal-sub">Choose which categories of cookies you allow.</p>' +
      '<div class="nova-toggle-row">' +
        '<div class="nova-toggle-label-group">' +
          '<span class="nova-toggle-label">Essential</span>' +
          '<span class="nova-toggle-desc">Required for the site to function</span>' +
        '</div>' +
        '<label class="nova-switch"><input type="checkbox" checked disabled><span class="nova-switch-track"></span><span class="nova-switch-thumb"></span></label>' +
      '</div>' +
      '<div class="nova-toggle-row">' +
        '<div class="nova-toggle-label-group">' +
          '<span class="nova-toggle-label">Analytics</span>' +
          '<span class="nova-toggle-desc">Help us understand how you use the site</span>' +
        '</div>' +
        '<label class="nova-switch"><input type="checkbox" id="novaToggleAnalytics"><span class="nova-switch-track"></span><span class="nova-switch-thumb"></span></label>' +
      '</div>' +
      '<div class="nova-toggle-row">' +
        '<div class="nova-toggle-label-group">' +
          '<span class="nova-toggle-label">Marketing</span>' +
          '<span class="nova-toggle-desc">Used to deliver relevant ads</span>' +
        '</div>' +
        '<label class="nova-switch"><input type="checkbox" id="novaToggleMarketing"><span class="nova-switch-track"></span><span class="nova-switch-thumb"></span></label>' +
      '</div>' +
      '<div class="nova-toggle-row">' +
        '<div class="nova-toggle-label-group">' +
          '<span class="nova-toggle-label">Personalization</span>' +
          '<span class="nova-toggle-desc">Tailor content to your preferences</span>' +
        '</div>' +
        '<label class="nova-switch"><input type="checkbox" id="novaTogglePersonalization"><span class="nova-switch-track"></span><span class="nova-switch-thumb"></span></label>' +
      '</div>' +
      '<div class="nova-modal-actions">' +
        '<button class="nova-btn nova-btn-ghost" data-nova-action="modal-cancel">Cancel</button>' +
        '<button class="nova-btn nova-btn-accent" data-nova-action="modal-save">Save Preferences</button>' +
      '</div>' +
    '</div>';

  // ── If already consented, skip ──
  if (localStorage.getItem(STORAGE_KEY)) return;

  // ── Create elements ──
  var banner  = document.createElement('div');
  banner.id   = 'novaCookieBanner';
  banner.className = 'nova-cookie-banner';
  banner.innerHTML = bannerHTML;

  var overlay  = document.createElement('div');
  overlay.id   = 'novaCookieOverlay';
  overlay.className = 'nova-cookie-overlay';
  overlay.innerHTML = overlayHTML;

  document.body.appendChild(banner);
  document.body.appendChild(overlay);

  // ── Helpers ──
  function dismiss() {
    banner.classList.add('hidden');
    banner.addEventListener('animationend', function handler() {
      banner.style.display = 'none';
      banner.removeEventListener('animationend', handler);
    });
  }

  function save(prefs) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      essential:       true,
      analytics:       !!prefs.analytics,
      marketing:       !!prefs.marketing,
      personalization: !!prefs.personalization,
      timestamp:       Date.now()
    }));
  }

  function openModal() {
    var stored = {};
    try { stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); } catch (_) {}
    overlay.querySelector('#novaToggleAnalytics').checked     = stored.analytics !== false;
    overlay.querySelector('#novaToggleMarketing').checked     = stored.marketing !== false;
    overlay.querySelector('#novaTogglePersonalization').checked = stored.personalization !== false;
    overlay.classList.add('open');
  }

  function closeModal() { overlay.classList.remove('open'); }

  // ── Event delegation ──
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-nova-action]');
    if (!btn) return;

    var action = btn.getAttribute('data-nova-action');

    if (action === 'accept') {
      save({ analytics: true, marketing: true, personalization: true });
      dismiss();
    } else if (action === 'reject') {
      save({ analytics: false, marketing: false, personalization: false });
      dismiss();
    } else if (action === 'manage') {
      openModal();
    } else if (action === 'modal-cancel') {
      closeModal();
    } else if (action === 'modal-save') {
      save({
        analytics:       overlay.querySelector('#novaToggleAnalytics').checked,
        marketing:       overlay.querySelector('#novaToggleMarketing').checked,
        personalization: overlay.querySelector('#novaTogglePersonalization').checked
      });
      closeModal();
      dismiss();
    }
  });

  // Close modal on backdrop click
  overlay.addEventListener('click', function (e) {
    if (e.target === overlay) closeModal();
  });
})();
