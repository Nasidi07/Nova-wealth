/**
 * Global Search Modal — Cmd+K / Ctrl+K
 * Nova Wealth Design System
 * Brand: #101C2E · #0AB68B · #F0F4F8
 */
(function () {
  'use strict';

  /* ── Brand Tokens ─────────────────────────────────────────── */
  const T = {
    bg: '#101C2E',
    card: '#1A3354',
    accent: '#0AB68B',
    text: '#F0F4F8',
    muted: '#94A3B8',
    border: '#1E3A5F',
    overlay: 'rgba(10,22,40,.85)',
    font: "'Inter', system-ui, sans-serif",
    mono: "'JetBrains Mono', monospace",
  };

  /* ── Path resolution ──────────────────────────────────────────── */
  /* Detect if script is loaded from screens/ dir vs root (index.html).
     All screen files live in screens/, index.html is at root. */
  var _inScreens = /\/screens\//.test(location.pathname);
  var _root = _inScreens ? '../' : '';
  var _screens = _inScreens ? '' : 'screens/';

  function resolve(file) {
    if (file === 'index.html') return _root + 'index.html';
    if (file === '404.html') return _screens + '404.html';
    return _screens + file;
  }

  /* ── Search Index ─────────────────────────────────────────── */
  const PAGES = [
    { title: 'Dashboard', path: resolve('dashboard.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>' },
    { title: 'Portfolio', path: resolve('portfolio.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>' },
    { title: 'Portfolio Detail', path: resolve('portfolio-detail.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>' },
    { title: 'Goals', path: resolve('goals.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>' },
    { title: 'Funding', path: resolve('funding.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>' },
    { title: 'Transfers', path: resolve('transfers.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>' },
    { title: 'Recurring', path: resolve('recurring.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>' },
    { title: 'Analytics', path: resolve('analytics.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>' },
    { title: 'Activity', path: resolve('activity.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>' },
    { title: 'Statements', path: resolve('statements.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>' },
    { title: 'Notifications', path: resolve('notifications.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>' },
    { title: 'Tax Center', path: resolve('tax-center.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>' },
    { title: 'Research', path: resolve('research.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>' },
    { title: 'Support', path: resolve('support.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>' },
    { title: 'Settings', path: resolve('settings.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>' },
    { title: 'Admin', path: resolve('admin.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>' },
    { title: 'Home', path: resolve('index.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>' },
    { title: 'Home Page', path: resolve('home.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>' },
    { title: 'Pricing', path: resolve('pricing.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>' },
    { title: 'About', path: resolve('about.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>' },
    { title: 'Contact', path: resolve('contact.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>' },
    { title: 'Help', path: resolve('help.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>' },
    { title: 'Legal', path: resolve('legal.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>' },
    { title: 'Referral', path: resolve('referral.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>' },
    { title: 'Learn', path: resolve('learn.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>' },
    { title: 'Fees', path: resolve('fees.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>' },
    { title: 'Careers', path: resolve('careers.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>' },
    { title: 'Risk Assessment', path: resolve('risk-assessment.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>' },
    { title: 'Beneficiaries', path: resolve('beneficiaries.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>' },
    { title: 'Account Types', path: resolve('account-types.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>' },
    { title: 'Mobile Dashboard', path: resolve('mobile.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>' },
    { title: 'Login', path: resolve('login.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>' },
    { title: 'Sign Up', path: resolve('auth.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>' },
    { title: '404 Not Found', path: resolve('404.html'), cat: 'Pages', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>' },
  ];

  const ACTIONS = [
    { title: 'Add Funds', path: resolve('funding.html'), cat: 'Actions', shortcut: '\u2318F', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>' },
    { title: 'Start Transfer', path: resolve('transfers.html'), cat: 'Actions', shortcut: '\u2318T', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/></svg>' },
    { title: 'Download Statement', path: resolve('statements.html'), cat: 'Actions', shortcut: '\u2318D', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>' },
    { title: 'Invite Friend', path: resolve('referral.html'), cat: 'Actions', shortcut: '\u2318I', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>' },
  ];

  const SETTINGS = [
    { title: 'Account Settings', path: resolve('settings.html'), cat: 'Settings', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>' },
    { title: 'Security', path: resolve('settings.html') + '#security', cat: 'Settings', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>' },
    { title: 'Notifications', path: resolve('settings.html') + '#notifications', cat: 'Settings', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>' },
    { title: 'Preferences', path: resolve('settings.html') + '#preferences', cat: 'Settings', icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>' },
  ];

  const ALL = [].concat(PAGES, ACTIONS, SETTINGS);
  var STORAGE_KEY = 'nova_search_recent';
  var MAX_RECENT = 5;

  /* ── Fuzzy match ──────────────────────────────────────────── */
  function fuzzy(query, text) {
    var q = query.toLowerCase();
    var t = text.toLowerCase();
    if (t.indexOf(q) !== -1) return { match: true, score: 100 - t.indexOf(q) };
    var qi = 0, score = 0, consecutive = 0;
    for (var ti = 0; ti < t.length && qi < q.length; ti++) {
      if (t[ti] === q[qi]) { qi++; consecutive++; score += consecutive * 10; } else { consecutive = 0; }
    }
    return qi === q.length ? { match: true, score: score } : { match: false, score: 0 };
  }

  function search(query) {
    if (!query.trim()) return { pages: [], actions: [], settings: [] };
    var results = [];
    for (var i = 0; i < ALL.length; i++) {
      var item = ALL[i];
      var r = fuzzy(query, item.title);
      if (r.match) {
        var boosted = item.title.toLowerCase().indexOf(query.toLowerCase()) === 0 ? 500 : 0;
        results.push({ title: item.title, path: item.path, cat: item.cat, icon: item.icon, shortcut: item.shortcut, score: r.score + boosted });
      }
    }
    results.sort(function (a, b) { return b.score - a.score; });
    var g = { pages: [], actions: [], settings: [] };
    results.forEach(function (r) {
      if (r.cat === 'Pages') g.pages.push(r);
      else if (r.cat === 'Actions') g.actions.push(r);
      else g.settings.push(r);
    });
    return g;
  }

  /* ── Recent searches ──────────────────────────────────────── */
  function getRecent() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch (e) { return []; }
  }
  function addRecent(title) {
    var list = getRecent().filter(function (r) { return r !== title; });
    list.unshift(title);
    if (list.length > MAX_RECENT) list.length = MAX_RECENT;
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); } catch (e) {}
  }

  /* ── CSS ──────────────────────────────────────────────────── */
  function buildCSS() {
    return [
      '*{margin:0;padding:0;box-sizing:border-box}',
      '.nova-search-overlay{position:fixed;inset:0;z-index:9999;display:flex;align-items:flex-start;justify-content:center;padding-top:min(20vh,160px);background:' + T.overlay + ';backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);opacity:0;visibility:hidden;transition:opacity .18s ease,visibility .18s ease}',
      '.nova-search-overlay[aria-hidden="false"]{opacity:1;visibility:visible}',
      '.nova-search-modal{width:min(580px,92vw);background:' + T.bg + ';border:1px solid ' + T.border + ';border-radius:16px;box-shadow:0 25px 80px rgba(0,0,0,.55);transform:scale(.96);transition:transform .2s cubic-bezier(.16,1,.3,1);overflow:hidden}',
      '.nova-search-overlay[aria-hidden="false"] .nova-search-modal{transform:scale(1)}',
      '.nova-search-input-wrap{display:flex;align-items:center;gap:12px;padding:14px 20px;border-bottom:1px solid ' + T.border + '}',
      '.nova-search-icon{width:20px;height:20px;color:' + T.muted + ';flex-shrink:0}',
      '.nova-search-input{flex:1;background:none;border:none;outline:none;color:' + T.text + ';font-family:' + T.font + ';font-size:15px;line-height:1.5}',
      '.nova-search-input::placeholder{color:' + T.muted + '}',
      '.nova-search-hint{font-family:' + T.mono + ';font-size:11px;color:' + T.muted + ';background:' + T.card + ';border:1px solid ' + T.border + ';border-radius:5px;padding:2px 7px;line-height:1.3;white-space:nowrap}',
      '.nova-search-results{max-height:400px;overflow-y:auto;padding:8px 0;scrollbar-width:thin;scrollbar-color:' + T.border + ' transparent}',
      '.nova-search-results::-webkit-scrollbar{width:6px}',
      '.nova-search-results::-webkit-scrollbar-track{background:transparent}',
      '.nova-search-results::-webkit-scrollbar-thumb{background:' + T.border + ';border-radius:3px}',
      '.nova-search-group-label{font-size:11px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:' + T.muted + ';padding:10px 20px 4px;user-select:none}',
      '.nova-search-item{display:flex;align-items:center;gap:12px;padding:10px 20px;cursor:pointer;color:' + T.text + ';font-size:14px;transition:background .1s}',
      '.nova-search-item[aria-selected="true"],.nova-search-item:hover,.nova-search-item.nova-active{background:' + T.card + '}',
      '.nova-search-item svg{width:18px;height:18px;color:' + T.muted + ';flex-shrink:0;stroke:currentColor;stroke-width:2;fill:none;stroke-linecap:round;stroke-linejoin:round}',
      '.nova-search-item[aria-selected="true"] svg,.nova-search-item:hover svg,.nova-search-item.nova-active svg{color:' + T.accent + '}',
      '.nova-search-item-title{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.nova-search-item-shortcut,.nova-search-item-path{font-size:11px;font-family:' + T.mono + ';color:' + T.muted + ';background:' + T.card + ';border:1px solid ' + T.border + ';border-radius:4px;padding:1px 6px;margin-left:auto;white-space:nowrap}',
      '.nova-search-footer{border-top:1px solid ' + T.border + ';padding:10px 20px;display:flex;align-items:center;gap:16px;font-size:11px;color:' + T.muted + ';font-family:' + T.mono + '}',
      '.nova-search-footer kbd{display:inline-flex;align-items:center;justify-content:center;min-width:22px;height:20px;background:' + T.card + ';border:1px solid ' + T.border + ';border-radius:4px;padding:0 5px;font-family:inherit;font-size:10px}',
      '.nova-search-empty{text-align:center;padding:32px 20px;color:' + T.muted + ';font-size:14px}',
      '.nova-search-trigger{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border:1px solid ' + T.border + ';background:' + T.card + ';border-radius:10px;cursor:pointer;color:' + T.muted + ';transition:color .15s,border-color .15s;flex-shrink:0}',
      '.nova-search-trigger:hover{color:' + T.accent + ';border-color:' + T.accent + '}',
      '.nova-search-trigger svg{width:18px;height:18px;stroke:currentColor;stroke-width:2;fill:none;stroke-linecap:round;stroke-linejoin:round}',
      '@media(max-width:640px){.nova-search-modal{width:100%;border-radius:12px}.nova-search-results{max-height:50vh}}',
    ].join('\n');
  }

  /* ── SVG Icons ────────────────────────────────────────────── */
  var SEARCH_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>';

  /* ── State ────────────────────────────────────────────────── */
  var overlay, input, resultsEl, activeIndex = 0, allItems = [], isOpen = false;

  function injectCSS() {
    if (document.getElementById('nova-search-css')) return;
    var s = document.createElement('style');
    s.id = 'nova-search-css';
    s.textContent = buildCSS();
    document.head.appendChild(s);
  }

  function buildModal() {
    injectCSS();
    overlay = document.createElement('div');
    overlay.className = 'nova-search-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-hidden', 'true');
    overlay.setAttribute('aria-label', 'Global search');

    var modal = document.createElement('div');
    modal.className = 'nova-search-modal';
    modal.setAttribute('role', 'combobox');
    modal.setAttribute('aria-expanded', 'false');

    var inputWrap = document.createElement('div');
    inputWrap.className = 'nova-search-input-wrap';

    var iconSpan = document.createElement('span');
    iconSpan.className = 'nova-search-icon';
    iconSpan.innerHTML = SEARCH_SVG;

    input = document.createElement('input');
    input.className = 'nova-search-input';
    input.type = 'text';
    input.placeholder = 'Search pages, settings, actions\u2026';
    input.setAttribute('autocomplete', 'off');
    input.setAttribute('autocorrect', 'off');
    input.setAttribute('autocapitalize', 'off');
    input.setAttribute('spellcheck', 'false');
    input.setAttribute('aria-label', 'Search');

    var hint = document.createElement('span');
    hint.className = 'nova-search-hint';
    hint.textContent = 'ESC';

    inputWrap.appendChild(iconSpan);
    inputWrap.appendChild(input);
    inputWrap.appendChild(hint);

    resultsEl = document.createElement('div');
    resultsEl.className = 'nova-search-results';
    resultsEl.setAttribute('role', 'listbox');
    resultsEl.setAttribute('aria-label', 'Search results');

    var footer = document.createElement('div');
    footer.className = 'nova-search-footer';
    footer.innerHTML = '<span>\u2191\u2193 navigate</span><span>\u23CE open</span><span>esc close</span>';

    modal.appendChild(inputWrap);
    modal.appendChild(resultsEl);
    modal.appendChild(footer);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    input.addEventListener('input', onInput);
    input.addEventListener('keydown', onKeydown);
    overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
    overlay.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  }

  /* ── Rendering ────────────────────────────────────────────── */
  function renderResults(query) {
    activeIndex = 0;
    var q = query.trim();

    if (!q) {
      var recent = getRecent();
      if (recent.length) {
        var html = '<div class="nova-search-group-label">Recent</div>';
        recent.forEach(function (title) {
          var item = ALL.find(function (i) { return i.title === title; });
          if (item) html += renderItemHTML(item);
        });
        resultsEl.innerHTML = html;
        bindItems();
      } else {
        resultsEl.innerHTML = '<div class="nova-search-empty">Type to search across pages, settings, and actions</div>';
      }
      return;
    }

    var r = search(q);
    var html = '';
    if (r.pages.length) {
      html += '<div class="nova-search-group-label">Pages</div>';
      r.pages.forEach(function (item) { html += renderItemHTML(item); });
    }
    if (r.actions.length) {
      html += '<div class="nova-search-group-label">Actions</div>';
      r.actions.forEach(function (item) { html += renderItemHTML(item); });
    }
    if (r.settings.length) {
      html += '<div class="nova-search-group-label">Settings</div>';
      r.settings.forEach(function (item) { html += renderItemHTML(item); });
    }
    if (!html) html = '<div class="nova-search-empty">No results found</div>';
    resultsEl.innerHTML = html;
    bindItems();
  }

  function renderItemHTML(item) {
    var tag = item.shortcut
      ? '<span class="nova-search-item-shortcut">' + item.shortcut + '</span>'
      : '<span class="nova-search-item-path">' + item.path + '</span>';
    return '<div class="nova-search-item" role="option" data-path="' + item.path + '" data-title="' + item.title + '">' + item.icon + '<span class="nova-search-item-title">' + item.title + '</span>' + tag + '</div>';
  }

  function bindItems() {
    allItems = Array.prototype.slice.call(resultsEl.querySelectorAll('.nova-search-item'));
    allItems.forEach(function (el, i) {
      el.addEventListener('click', function () { selectItem(el); });
      el.addEventListener('mouseenter', function () { setIndex(i); });
    });
    if (allItems.length) setIndex(0);
  }

  function setIndex(i) {
    allItems.forEach(function (el) { el.removeAttribute('aria-selected'); el.classList.remove('nova-active'); });
    activeIndex = Math.max(0, Math.min(i, allItems.length - 1));
    if (allItems[activeIndex]) {
      allItems[activeIndex].setAttribute('aria-selected', 'true');
      allItems[activeIndex].classList.add('nova-active');
      allItems[activeIndex].scrollIntoView({ block: 'nearest' });
    }
  }

  function selectItem(el) {
    var path = el.getAttribute('data-path');
    var title = el.getAttribute('data-title');
    addRecent(title);
    close();
    if (path) {
      try { window.location.href = path; } catch (e) {}
    }
  }

  function onInput() { renderResults(input.value); }

  function onKeydown(e) {
    if (e.key === 'ArrowDown') { e.preventDefault(); setIndex(activeIndex + 1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setIndex(activeIndex - 1); }
    else if (e.key === 'Enter') { e.preventDefault(); if (allItems[activeIndex]) selectItem(allItems[activeIndex]); }
  }

  /* ── Open / Close ─────────────────────────────────────────── */
  function open() {
    if (isOpen) return;
    isOpen = true;
    overlay.setAttribute('aria-hidden', 'false');
    renderResults('');
    input.value = '';
    requestAnimationFrame(function () { input.focus(); });
    document.body.style.overflow = 'hidden';
  }

  function close() {
    if (!isOpen) return;
    isOpen = false;
    overlay.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  function toggle() { isOpen ? close() : open(); }

  /* ── Keyboard listener ────────────────────────────────────── */
  document.addEventListener('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault();
      toggle();
    }
  });

  /* ── Trigger button helper ────────────────────────────────── */
  function createTriggerButton() {
    var btn = document.createElement('button');
    btn.className = 'nova-search-trigger';
    btn.type = 'button';
    btn.setAttribute('aria-label', 'Search (\u2318K)');
    btn.innerHTML = SEARCH_SVG;
    btn.addEventListener('click', toggle);
    return btn;
  }

  /* ── Init ─────────────────────────────────────────────────── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', buildModal);
  } else {
    buildModal();
  }

  /* ── Public API ───────────────────────────────────────────── */
  window.NovaSearch = { open: open, close: close, toggle: toggle, createTriggerButton: createTriggerButton };
})();
